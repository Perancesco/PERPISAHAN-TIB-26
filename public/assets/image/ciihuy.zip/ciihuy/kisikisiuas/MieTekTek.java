package kisikisiuas;

public class MieTekTek extends Jualan {
	

	private long hargaMieLebar = 2000;
	private long hargaMieLurus = 1000;
	private long hargaMieKeriting = 1500;
	
	public MieTekTek() {
	setNama("Mie tek tek");
	setHarga(8000);
	setKuantitas(5);
	}
	
	public long pilihJenisMie (int pilihan) {
		long hargaJenisMie = 0;
		if(pilihan==1) {
			hargaJenisMie = hargaMieLebar;
		} else if (pilihan==2)
			hargaJenisMie = hargaMieLurus;
		else {
			hargaJenisMie = hargaMieKeriting;
		}
		return hargaJenisMie;
	}	
	
	@Override
	public void getInfo() {
		    System.out.println("2. " + getNama() + " harga: Rp. " + getHarga() + " stok: " + getKuantitas());
	}
}


