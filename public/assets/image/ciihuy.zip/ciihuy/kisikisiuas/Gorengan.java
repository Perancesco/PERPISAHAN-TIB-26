package kisikisiuas;

public class Gorengan extends Jualan {
	
	private long hargaCabe = 500;
	public Gorengan () {
	setNama("Gorengan");
	setHarga(2000);
	setKuantitas(10);
	}
	
	public long tambahCabe(int banyak) {
		return hargaCabe * banyak;
	}
	
	@Override
	public void getInfo() {
		    System.out.println("1. " + getNama() + " harga: Rp. " + getHarga() + " stok: " + getKuantitas());
	}
}
