package kisikisiuas;

abstract public class Jualan  {
	private String nama;
	private long harga;
	private int kuantitas;
	
	public String getNama() {
		return nama;
	}
	public void setNama(String nama) {
		this.nama = nama;
	}
	
	public long getHarga() {
		return harga;
	}
	public void setHarga(long harga) {
		this.harga = harga;
	}
	
	public int getKuantitas() {
		return kuantitas;
	}
	public void setKuantitas(int kuantitas) {
		this.kuantitas = kuantitas;
	}
	
	public abstract void getInfo();
}

