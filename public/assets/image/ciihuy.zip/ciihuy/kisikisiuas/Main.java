package kisikisiuas;
import java.util.Scanner;
import java.util.List;
import java.util.ArrayList;

public class Main {

	public static void main(String[] args) {
	
		Warung warung = new Warung();
		Gorengan gorengan = new Gorengan();
		MieTekTek mietektek = new MieTekTek();
		warung.tambahJualan(gorengan);
		warung.tambahJualan(mietektek);
		warung.lihatJualan();
		System.out.println ("Warung Bik Kori------------");
		Scanner input = new Scanner(System.in);
		int banyakCabe=0;
		long totalHargaCabe=0;

		System.out.println("masukkan pilihan yang ingin kamu beli (1/2)");
		int pilihanMakanan = input.nextInt();
		if (pilihanMakanan == 1) {
			System.out.println ("tambah cabe? 1.Ya 2.Tidak");
			int pilihanCabe = input.nextInt();
			if (pilihanCabe == 1) {
				System.out.println ("berapa cabe?");
				banyakCabe = input.nextInt();
				totalHargaCabe = gorengan.tambahCabe(banyakCabe);
			}
			else {
				System.out.println ("ga pake cabe");
			}
		System.out.println ("berapa banyak tahu?");
		int banyakTahu = input.nextInt();
		long totalHargaTahu = gorengan.getHarga() * banyakTahu;
		long total = totalHargaTahu +totalHargaCabe;
		System.out.println("Anda membeli tahu sebanyak : " + banyakTahu);
		System.out.println("dan tambah cabe sebanyak : " + banyakCabe);
		System.out.println("Total belanja anda : " + total);
		}
		
		else if (pilihanMakanan == 2) {
			System.out.println ("Mie Lebar = 2000");
			System.out.println ("Mie Lurus = 1000");
			System.out.println ("Mie Keriting = 1500");
			System.out.println ("pilih jenis mie (1/2/3)");
			int pilihan = input.nextInt();
			
			long hargaJenisMie = mietektek.pilihJenisMie(pilihan);
			int banyakMie=0;
			long totalHargaMie = 0;
			
			if(pilihan==1) {
				System.out.println("Berapa banyak mie?");
				banyakMie = input.nextInt();
				totalHargaMie = mietektek.getHarga() * banyakMie + hargaJenisMie;
			}
			else if (pilihan==2) {
				System.out.println("Berapa banyak mie?");
				banyakMie = input.nextInt();
				totalHargaMie = mietektek.getHarga() * banyakMie + hargaJenisMie;
			}
			else if (pilihan==3) {
				System.out.println("Berapa banyak mie?");
				banyakMie = input.nextInt();
				totalHargaMie = mietektek.getHarga() * banyakMie + hargaJenisMie;
			}
		else {
		}
			System.out.println("Anda beli mie sebanyak : " + banyakMie);
			System.out.println("dengan jenis mie 1. lebar 2. lurus 3. keriting : " + pilihan);
			System.out.println("Total belanja anda : " + totalHargaMie);

	}
	}
}