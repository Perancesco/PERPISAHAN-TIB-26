package kisikisiuas;
import java.util.List;
import java.util.ArrayList;

public class Warung {
	
	private List<Jualan> listJualan;
	
	public Warung() {
		listJualan = new ArrayList<>();
	}
	
	public void tambahJualan(Jualan jualan) {
		listJualan.add(jualan);
	}
	public void lihatJualan() {
		listJualan.get(0).getInfo();
        listJualan.get(1).getInfo();
	}
}
